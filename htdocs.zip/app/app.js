var eventApp = angular.module (
	'event',
	[
		'ngRoute',
		'ngMaterial'
	]
);

eventApp.config(function($mdDateLocaleProvider) {
	$mdDateLocaleProvider.formatDate = function(date) {
		return moment(date).format('DD.MM.YYYY');
	};
});