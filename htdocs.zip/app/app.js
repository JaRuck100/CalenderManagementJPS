var eventApp = angular.module (
	'event',
	[
		'ngRoute',
		'ngMaterial',
		'ui-notification'
	]
);

eventApp.config(function($mdDateLocaleProvider) {
	$mdDateLocaleProvider.formatDate = function(date) {
		return moment(date).format('DD.MM.YYYY');
	};
});