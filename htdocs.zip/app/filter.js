/* -- Login App Filter -- */
// Date Format Filter for Views
eventApp.filter('filterDate', ['$filter', function($filter) {
	return function(input) {
		if (input != '0000-00-00' && input != '0000-00-00 00:00:00') {
			return $filter('date')(new Date(input), 'dd.MM.yyyy');
		}
		return ' - ';
	};
}]);

// DateTime Format Filter for Views
eventApp.filter('filterDateTime', ['$filter', function($filter) {
	return function(input) {
		if (input != '0000-00-00' && input != '0000-00-00 00:00:00') {
			return $filter('date')(new Date(input), 'dd.MM.yyyy HH:mm');
		}
		return ' - ';
	};
}]);
/* -- Login App Filter Ende -- */