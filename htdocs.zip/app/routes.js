eventApp.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
	$locationProvider.html5Mode(true);
	$routeProvider.when('/home', {
		templateUrl: 'views/home.html'
	}).when('/add', {
		templateUrl: 'views/add.html'
	}).when('/edit/:id', {
		templateUrl: 'views/edit.html'
	}).when('/login', {
		templateUrl: 'views/login.html'
	}).when('/register', {
		templateUrl: 'views/register.html'
	}).when('/changepassword',{
		templateUrl: 'views/changepassword.html'
	}).when('/logout', {
		templateUrl: 'views/logout.html'
	}).otherwise({
		redirectTo: '/login'
	});
}]);