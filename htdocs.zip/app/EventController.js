eventApp.controller('LoginController', ['$scope', '$http', '$rootScope', '$location', '$window', function($scope, $http, $rootScope, $location, $window) {
	if ($window.sessionStorage.access && $window.sessionStorage.username) {
		$rootScope.username = $window.sessionStorage.username;
		$rootScope.access = $window.sessionStorage.access;
		$rootScope.userId = $window.sessionStorage.userId;
		$location.path('/home');
	}

	$rootScope.site = 'login';
	$scope.user = {};

	this.login = function() {
		$scope.dataLoading = true;	

		var encodedString = 'url=/login&username=' +
		$scope.user.username + '&password=' +
		$scope.user.password;

		console.log(encodedString);

		// -- AJAX Funktion zur exe Datei --
		$http({
			method: 'post',
			url: 'cgi-bin/CalenderManagementJPS.exe',
			data: encodedString,
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(data, status, headers, config) {
			console.log(data);

			var split = data.split(';');

			if (split[0] == 'y') {
				$window.sessionStorage.access = true;
				$window.sessionStorage.userId = split[1];
				$window.sessionStorage.username = $scope.user.username;
				$location.path('/home');
			} else {
				$scope.error = 'Das Passwort oder der Benutzername stimmen nicht.';
			}
			$scope.dataLoading = false;
		}).error(function(data, status, headers, config) {

		});
	};
}]);

eventApp.controller('RegisterController', ['$scope', '$http', '$rootScope', '$location', '$mdDialog', '$window', function($scope, $http, $rootScope, $location, $mdDialog, $window) {
	if ($window.sessionStorage.access && $window.sessionStorage.username) {
		$rootScope.username = $window.sessionStorage.username;
		$rootScope.access = $window.sessionStorage.access;
		$rootScope.userId = $window.sessionStorage.userId;
		$location.path('/home');
	}
	$rootScope.site = 'register';
	$scope.user = {};

	this.register = function() {
		$scope.dataLoading = true;

		if ($scope.user.password == $scope.user.password2) {
			var encodedString = 'url=/register&username='+
			$scope.user.username + '&password=' +
			$scope.user.password + '&passwordRepeat=' +
			$scope.user.password2;

			console.log(encodedString);

			$http({
				method: 'post',
				url: 'cgi-bin/CalenderManagementJPS.exe',
				data: encodedString,
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(data, status, headers, config) {
				if (data == 'y') {
					$location.path('/login');
				} else if (data == 'nu') {
					$scope.error = 'Den User gibt es schon.';
				} else if(data == 'np') {
					$scope.error = 'Passwörter stimmen nicht überein.';
				}
				$scope.dataLoading = false;
			}).error(function(data, status, headers, config) {

			});
		} else {
			$scope.error = 'Die Passwörter müssen übereinstimmen!';
			$scope.dataLoading = false;
		}
	};
}]);

eventApp.controller('HomeController', ['$scope', '$http', '$rootScope', '$location', '$mdDialog', '$window', function($scope, $http, $rootScope, $location, $mdDialog, $window) {
	if ($window.sessionStorage.access && $window.sessionStorage.username) {
		$rootScope.username = $window.sessionStorage.username;
		$rootScope.access = $window.sessionStorage.access;
		$rootScope.userId = $window.sessionStorage.userId;
	} else {
		$location.path('/login');
	}

	// -- Benutzerstatus prüfen --
	var encodedString = 'url=/check_user&id=' + $rootScope.userId;
	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		if (data != 'y') {
			$location.path('/logout');
		}
	}).error(function(data, status, headers, config) {

	});

	$rootScope.site = 'home';
	$scope.dataLoading = false;

	var encodedString = 'url=/show_events';

	console.log(encodedString);

	//serverseitig filtern
	
	// -- AJAX Funktion zur exe Datei -- 
	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		$scope.events = data;
		$scope.dataLoading = false;
	}).error(function(data, status, headers, config) {

	});

	// Test Ergebnisse
	// $scope.events = [
	// 	{"id": "1", "title": "test", "start": "2017-04-01 00:00", "end": "2017-04-02 00:00","description":"blub"},
	// 	{"id": "2", "title": "test-2", "start": "2017-05-01 00:00", "end": "2017-05-01 10:00"},
	// ];

	$scope.add = function() {
		$location.path('/add');
	};

	$scope.edit = function(event) {
		$location.path('/edit/' + event.id);
	};

	$scope.remove = function(event) {
		var confirm = $mdDialog.confirm()
			.title('Wirklich löschen?')
			.content('Das Event ' + event.title + ' wird unwiderruflich gelöscht')
			.ariaLabel('Löschen')
			.ok('Löschen')
			.cancel('Abbrechen');
	
		$mdDialog.show(confirm).then(function() {
			$scope.dataLoading = true;
			// -- Funktion zum löschen --
			var encodedString = 'url=/delete&id=' +
			event.id;

			console.log(encodedString);

			$http({
				method: 'post',
				url: 'cgi-bin/CalenderManagementJPS.exe',
				data: encodedString,
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(data, status, headers, config) {
				if (data == 'y') {
					// -- Funktion zum laden der Ergebnisse (nach dem löschen für das Update der View)
					var encodedString = 'url=/show_events';

					$http({
						method: 'post',
						url: 'cgi-bin/CalenderManagementJPS.exe',
						data: encodedString,
						headers: {'Content-Type': 'application/x-www-form-urlencoded'}
					}).success(function(data, status, headers, config) {
						$scope.events = data;
						$scope.dataLoading = false;
					}).error(function(data, status, headers, config) {

					});
				}
			}).error(function(data, status, headers, config) {

			});
			console.log(event.title + ' wurde gelöscht');
		}, function() {
			$scope.dataLoading = false;
		})
	};
}]);

eventApp.controller('AddController', ['$scope', '$http', '$rootScope', '$location', '$window', function($scope, $http, $rootScope, $location, $window) {
	if ($window.sessionStorage.access && $window.sessionStorage.username) {
		$rootScope.username = $window.sessionStorage.username;
		$rootScope.access = $window.sessionStorage.access;
		$rootScope.userId = $window.sessionStorage.userId;
	} else {
		$location.path('/login');
	}

	// -- Benutzerstatus prüfen --
	var encodedString = 'url=/check_user&id=' + $rootScope.userId;
	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		if (data != 'y') {
			$location.path('/logout');
		}
	}).error(function(data, status, headers, config) {

	});

	$rootScope.site = 'add';
	$scope.event = {};

	this.add = function() {
		$scope.dataLoading = true;

		var startadd = document.getElementById('startadd').value;
		var endadd = document.getElementById('endadd').value;

		var encodedString = 'url=/add_event&title=' +
		$scope.event.title + '&start=' +
		startadd + '&end=' +
		endadd + '&description=' +
		$scope.event.description;

		console.log(encodedString);

		$http({
			method: 'post',
			url: 'cgi-bin/CalenderManagementJPS.exe',
			data: encodedString,
			headers: {'Content-Type': 'application/x-www-form-urlencoded'} 
		}).success(function(data, status, headers, config) {
			console.log(data);

			if (data == 'y') {
				$location.path('/home');
			}
		}).error(function(data, status, headers, config) {

		});
	};

	$('#datetimepickerstartadd').datetimepicker({
		locale: 'de',
		format: 'YYYY-MM-DD HH:mm'
	});


	$('#datetimepickerendadd').datetimepicker({
		locale: 'de',
		format: 'YYYY-MM-DD HH:mm'
	});

}]);

eventApp.controller('EditController', ['$scope', '$http', '$rootScope', '$location', '$routeParams', '$window', function($scope, $http, $rootScope, $location, $routeParams, $window) {
	if ($window.sessionStorage.access && $window.sessionStorage.username) {
		$rootScope.username = $window.sessionStorage.username;
		$rootScope.access = $window.sessionStorage.access;
		$rootScope.userId = $window.sessionStorage.userId;
	} else {
		$location.path('/login');
	}

	// -- Benutzerstatus prüfen --
	var encodedString = 'url=/check_user&id=' + $rootScope.userId;
	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		if (data != 'y') {
			$location.path('/logout');
		}
	}).error(function(data, status, headers, config) {

	});

	$rootScope.site = 'home';
	$scope.dataLoading = true;
	
	var encodedString = 'url=/event_search&id=' +
	$routeParams.id;

	console.log(encodedString);

	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		console.log(data);
		$scope.event = data;
		$scope.dataLoading = false;
	}).error(function(data, status, headers, config) {

	});
	// $scope.event = {
	// 	id: $routeParams.id,
	// 	title: 'Ich bin ein Titel',
	// 	start: '2017-04-01 00:00',
	// 	end: '2017-04-01 01:00',
	// 	description: 'Blubb'
	// };
	//$scope.dataLoading = false;


	this.edit = function() {
		$scope.dataLoading = true;

		var startedit = document.getElementById('startedit').value;
		var endedit = document.getElementById('endedit').value;

		var encodedString = 'url=/change_event&title=' +
		$scope.event.title + '&start=' +
		startedit + '&end=' +
		endedit + '&description=' +
		$scope.event.description + '&id=' +
		$routeParams.id;

		console.log(encodedString);

		$http({
			method: 'post',
			url: 'cgi-bin/CalenderManagementJPS.exe',
			data: encodedString,
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(data, status, headers, config) {
			console.log(data);
			if (data == 'y') {
				$location.path('/home');
			}
		}).error(function(data, status, headers, config) {

		});
	};

	$('#datetimepickerstartedit').datetimepicker({
		locale: 'de',
		format: 'YYYY-MM-DD HH:mm'
	});


	$('#datetimepickerendedit').datetimepicker({
		locale: 'de',
		format: 'YYYY-MM-DD HH:mm'
	});
}]);

eventApp.controller('LogoutController', ['$scope', '$http', '$rootScope', '$location', '$window', function($scope, $http, $rootScope, $location, $window) {
	var encodedString = 'url=/logout';
	
	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		if (data == 'y') {
			$rootScope.access = false;
			$window.sessionStorage.clear();
			$location.path('/login');
		}
	}).error(function(data, status, headers, config) {

	});
}]);

eventApp.controller('ChangePasswordController', ['$scope', '$http', '$rootScope', '$location', '$window', function($scope, $http, $rootScope, $location, $window) {
	if ($window.sessionStorage.access && $window.sessionStorage.username) {
		$rootScope.username = $window.sessionStorage.username;
		$rootScope.access = $window.sessionStorage.access;
		$rootScope.userId = $window.sessionStorage.userId;
	} else {
		$location.path('/login');
	}
	$rootScope.site = 'changepassword';

	// -- Benutzerstatus prüfen --
	var encodedString = 'url=/check_user&id=' + $rootScope.userId;
	$http({
		method: 'post',
		url: 'cgi-bin/CalenderManagementJPS.exe',
		data: encodedString,
		headers: {'Content-Type': 'application/x-www-form-urlencoded'}
	}).success(function(data, status, headers, config) {
		if (data != 'y') {
			$location.path('/logout');
		}
	}).error(function(data, status, headers, config) {

	});

	this.changepassword = function() {
		$scope.dataLoading = true;

		if ($scope.password.newPassword == $scope.password.newPasswordRepeat) {
			var encodedString = 'url=/change_password&password='+
			$scope.password.oldPassword + '&newPassword=' +
			$scope.password.newPassword + '&passwordRepeat=' +
			$scope.password.newPasswordRepeat;

			console.log(encodedString);

			$http({
				method: 'post',
				url: 'cgi-bin/CalenderManagementJPS.exe',
				data: encodedString,
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(data, status, headers, config) {
				if (data == 'y1') {
					$location.path("/home");
				} else if (data == 'n') {
					$scope.error = 'Die neuen Passwörter müssen übereinstimmen!';
					$scope.dataLoading = false;
				}

				$scope.dataLoading = false;
			}).error(function(data, status, headers, config) {

			});
		} else {
			$scope.error = 'Die neuen Passwörter müssen übereinstimmen!';
			$scope.dataLoading = false;
		}
	};
}]);